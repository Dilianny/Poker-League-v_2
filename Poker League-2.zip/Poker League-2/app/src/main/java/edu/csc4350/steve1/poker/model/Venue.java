package edu.csc4350.steve1.poker.model;

public class Venue {
    private long id;
    private String name;
    private String address;
    private byte[] image;
    private double latitude;
    private double longitude;

    public Venue(String n, String a) {
        name = n;
        address = a;
    }

    public Venue(String n, String a, byte[] image,double latitude, double longitude) {
        this(n, a);
        this.image = image;
        this.latitude=latitude;
        this.longitude=longitude;
    }

    public Venue(long i, String n, String a) {
        this(n, a);
        id = i;
    }

    public Venue(long id, String name, String address, byte[] image,double latitude, double longitude) {
        this(name, address, image,latitude,longitude);
        this.id = id;
    }

    public Venue() {
        id = 0;
        name = "";
        address = "";
        latitude=0.0;
        longitude=0.0;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    //lat1 and lon1 are from venue address
    public double distanceToVenue(double lat1, double lon1){
        double R = 6372.8;
        double dLat = Math.toRadians(this.latitude - lat1);
        double dLon = Math.toRadians(this.longitude - lon1);
        lat1 = Math.toRadians(lat1);
        double lat2 = Math.toRadians(this.latitude);

        double a = Math.pow(Math.sin(dLat / 2),2) + Math.pow(Math.sin(dLon / 2),2) * Math.cos(lat1) * Math.cos(lat2);
        double c = 2 * Math.asin(Math.sqrt(a));
        return R * c;
    }
    @Override
    public String toString() {
        return name;
    }
}
