package edu.csc4350.steve1.poker.views.venue;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.view.View;

import edu.csc4350.steve1.poker.R;
import edu.csc4350.steve1.poker.model.Venue;
import edu.csc4350.steve1.poker.model.GeocodingLocation;
import edu.csc4350.steve1.poker.providers.PokerDatabase;

public class AddVenueActivity extends AppCompatActivity implements LocationListener {

LocationManager lm;
boolean GpsStatus = false ;
String provider;
Location l;
    private static final int REQUEST_GET_IMAGE_FILE = 1001;
    private static final int REQUEST_CODE_READ_EXTERNAL_STORAGE_PERMISSION = 1002;
    //private static final int REQUEST_CODE_READ_EXTERNAL_STORAGE_PERMISSION_1 = 1003;

    public static String ARG_VENUE_ID = "venueId";

    private EditText edtName, edtAddress;
    TextView edtLatitude, edtLongitude, venueaddr;
    private Button chooseImage;
    private ImageView image;
    private Button addVenueButton, addLocation;


    private byte[] selectedFile;

    private PokerDatabase venueDatabase;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getSupportActionBar().hide();
        setContentView(R.layout.activity_add_venue);

        // Request user to grant write external storage permission.
        //ActivityCompat.requestPermissions(AddVenueActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_READ_EXTERNAL_STORAGE_PERMISSION_1);
        ActivityCompat.requestPermissions(AddVenueActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        final long venueId = getIntent().getLongExtra(ARG_VENUE_ID, -1);
        venueDatabase = PokerDatabase.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtName = findViewById(R.id.edtName);
        edtAddress = findViewById(R.id.edtAddress);
        edtLatitude = findViewById(R.id.edtLatitude);
        edtLongitude = findViewById(R.id.edtLongitude);
        image = findViewById(R.id.image);
        chooseImage = findViewById(R.id.chooseImage);
        addVenueButton = findViewById(R.id.addVenueButton);
        addLocation=findViewById(R.id.addLocation);
        venueaddr=findViewById(R.id.venueaddr);
        //added
        //get location service
        lm=(LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
        Criteria c=new Criteria();
        provider=lm.getBestProvider(c, false);

        addLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        CheckGpsStatus();
        if(GpsStatus == true) {
            if (provider != null) {
                if (ActivityCompat.checkSelfPermission(
                        AddVenueActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        &&
                        ActivityCompat.checkSelfPermission(AddVenueActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                                != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                l = lm.getLastKnownLocation(provider);
                lm.requestLocationUpdates(provider, 5000, 7, AddVenueActivity.this);
                if (l != null) {

                    //display on text view
                    edtLongitude.setText( ""+l.getLongitude());
                    edtLatitude.setText( ""+l.getLatitude());
                }
            }
        }else {
                edtLongitude.setText("No Provider");
                edtLatitude.setText("No Provider");
                Toast.makeText(AddVenueActivity.this, "Please Enable GPS First", Toast.LENGTH_LONG).show();
            }

//Geolocation
                String address = edtAddress.getText().toString();

                //GeocodingLocation locationAddress = new GeocodingLocation();
                //locationAddress.getAddressFromLocation(address, getApplicationContext(), new GeocoderHandler());
            }
        });

        chooseImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Check whether this app has write external storage permission or not.
                int writeExternalStoragePermission = ActivityCompat.checkSelfPermission(AddVenueActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
                // If do not grant write external storage permission.
                if (writeExternalStoragePermission != PackageManager.PERMISSION_GRANTED) {
                    // Request user to grant write external storage permission.
                    ActivityCompat.requestPermissions(AddVenueActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_READ_EXTERNAL_STORAGE_PERMISSION);
                } else {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_GET_IMAGE_FILE);
                }
            }
        });

        if (venueId != -1) {
            Venue venue = venueDatabase.getVenue(venueId);
            edtName.setText(venue.getName());
            edtAddress.setText(venue.getAddress());
            edtLatitude.setText(String.valueOf(venue.getLatitude()));
            edtLongitude.setText(String.valueOf(venue.getLongitude()));

            ByteArrayInputStream imageStream = new ByteArrayInputStream(venue.getImage());
            Bitmap theImage = BitmapFactory.decodeStream(imageStream);
            image.setImageBitmap(theImage);

            toolbar.setTitle("Update Venue");
            addVenueButton.setText("Update Venue");
        }

        addVenueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Thread.currentThread().interrupt();

                String name = edtName.getText().toString().trim();
                String address = edtAddress.getText().toString().trim();
                String latitude = edtLatitude.getText().toString();
                String longitude = edtLongitude.getText().toString();

                if (name == null || name.isEmpty()) {
                    edtName.setError("Name is empty!");
                    return;
                }

               if (address == null || address.isEmpty()) {
                    edtAddress.setError("Address is empty!");
                    return;
                }

                if (latitude == null || latitude.isEmpty()) {
                    edtLatitude.setError("Address is empty!");
                    return;
                }


                if (longitude == null || longitude.isEmpty()) {
                    edtLongitude.setError("Address is empty!");
                    return;
                }

                if (selectedFile == null) {
                    Toast.makeText(getApplicationContext(), "Please select a image to add venue.", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (venueId != -1) {
                    Venue venue = new Venue(venueId, name, address, selectedFile, Double.valueOf(latitude), Double.valueOf(longitude));
                    venueDatabase.updateVenue(venue);
                } else {
                    Venue venue = new Venue(name, address, selectedFile, Double.valueOf(latitude), Double.valueOf(longitude));
                    venueDatabase.addVenue(venue);
                }
                Intent intent = new Intent();
                intent.putExtra(ARG_VENUE_ID, venueId);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }


    private class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    locationAddress = bundle.getString("address");
                    //Log.d("lat", locationAddress);
                    break;
                default:
                    locationAddress = null;
            }
           // venueaddr.setText(locationAddress);
        }
    }
    public void CheckGpsStatus(){

        GpsStatus = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    //If you want location on changing place also than use below method
    //otherwise remove all below methods and don't implement location listener
    @Override
    public void onLocationChanged(Location arg0)
    {
        double lng=l.getLongitude();
        double lat=l.getLatitude();
        edtLongitude.setText("" +lng);
        edtLatitude.setText(""+lat);
    }

    @Override
    public void onProviderDisabled(String arg0) {
        // TODO Auto-generated method stub
    }
    @Override
    public void onProviderEnabled(String arg0) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
        // TODO Auto-generated method stub
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == RESULT_OK) {
                if (requestCode == REQUEST_GET_IMAGE_FILE) {
                    Uri selectedImageUri = data.getData();
                    // Get the path from the Uri
                    final String path = getPathFromURI(selectedImageUri);
                    if (path != null) {
                        File f = new File(path);
                        selectedImageUri = Uri.fromFile(f);
                        selectedFile = readContentIntoByteArray(f);
                    }
                    // Set the image in ImageView
                    image.setImageURI(selectedImageUri);
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "An error occurred while selection file.", Toast.LENGTH_SHORT).show();
            Log.e("FileSelectorActivity", "File select error", e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_READ_EXTERNAL_STORAGE_PERMISSION) {
            int grantResultsLength = grantResults.length;
            if (grantResultsLength > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_GET_IMAGE_FILE);
            } else {
                Toast.makeText(getApplicationContext(), "You denied write external storage permission.", Toast.LENGTH_LONG).show();
            }
        }
    }

    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, projection, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    private byte[] readContentIntoByteArray(File file) {
        FileInputStream fileInputStream = null;
        byte[] bFile = new byte[(int) file.length()];
        try {
            //convert file into array of bytes
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bFile);
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bFile;
    }
}
