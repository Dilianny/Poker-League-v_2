package edu.csc4350.steve1.poker.holders;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayInputStream;

import edu.csc4350.steve1.poker.R;
import edu.csc4350.steve1.poker.model.Venue;

public class VenueViewHolder extends RecyclerView.ViewHolder {
    private TextView venueTextView;
    private ImageView venueImageView;

    public VenueViewHolder(View itemView) {
        super(itemView);

        venueTextView = itemView.findViewById(R.id.venueName);
        venueImageView = itemView.findViewById(R.id.image);
    }

    public void bindView(Venue venue) {
        venueTextView.setText(venue.getName());

        ByteArrayInputStream imageStream = new ByteArrayInputStream(venue.getImage());
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);
        venueImageView.setImageBitmap(theImage);
    }
}