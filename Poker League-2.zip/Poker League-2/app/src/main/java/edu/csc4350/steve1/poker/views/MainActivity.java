package edu.csc4350.steve1.poker.views;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import edu.csc4350.steve1.poker.R;
import edu.csc4350.steve1.poker.providers.PokerDatabase;
import edu.csc4350.steve1.poker.views.player.DetailsActivity;
import edu.csc4350.steve1.poker.views.player.PlayerListFragment;
import edu.csc4350.steve1.poker.views.tournament.TournamentDetailsActivity;
import edu.csc4350.steve1.poker.views.tournament.TournamentListFragment;
import edu.csc4350.steve1.poker.views.venue.VenueDetailsActivity;
import edu.csc4350.steve1.poker.views.venue.VenueListFragment;

import static edu.csc4350.steve1.poker.views.player.DetailsActivity.EXTRA_PLAYER_ID;
import static edu.csc4350.steve1.poker.views.tournament.TournamentDetailsActivity.EXTRA_TOURNAMENT_ID;
import static edu.csc4350.steve1.poker.views.venue.VenueDetailsActivity.EXTRA_VENUE_ID;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, PlayerListFragment.OnPlayerSelectedListener, TournamentListFragment.OnTournamentSelectedListener, VenueListFragment.OnVenueSelectedListener {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        if (savedInstanceState == null) {
            toolbar.setTitle("Player");
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.list_fragment_container, new PlayerListFragment())
                    .commitAllowingStateLoss();
        }
    }

    @Override
    public void onPlayerSelected(long playerId) {
        // Send the band ID of the clicked button to DetailsActivity
        Intent intent = new Intent(this, DetailsActivity.class);
        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_PLAYER_ID, playerId);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onPlayerDeleted(long playerId) {
        PokerDatabase.getInstance(this).deletePlayer(playerId);
    }

    @Override
    public void onTournamentSelected(long tournamentId) {
        // Send the band ID of the clicked button to DetailsActivity
        Intent intent = new Intent(this, TournamentDetailsActivity.class);
        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_TOURNAMENT_ID, tournamentId);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onTournamentDeleted(long tournamentId) {
        PokerDatabase.getInstance(this).deleteTournament(tournamentId);
    }

    @Override
    public void onVenueSelected(long venueId) {
        // Send the band ID of the clicked button to VenueDetailsActivity
        Intent intent = new Intent(this, VenueDetailsActivity.class);
        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_VENUE_ID, venueId);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onVenueDeleted(long venueId) {
        PokerDatabase.getInstance(this).deleteVenue(venueId);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int selectedId = menuItem.getItemId();

        switch (selectedId) {
            case R.id.navigation_player:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.list_fragment_container, new PlayerListFragment())
                        .commitAllowingStateLoss();
                toolbar.setTitle("Player");
                break;
            case R.id.navigation_tournament:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.list_fragment_container, new TournamentListFragment())
                        .commitAllowingStateLoss();
                toolbar.setTitle("Tournament");
                break;
            case R.id.navigation_venue:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.list_fragment_container, new VenueListFragment())
                        .commitAllowingStateLoss();
                toolbar.setTitle("Venue");
                break;
            default:
                // do nothing
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
